export interface Item{
    description: string;
    image: string;
    mrpPrice : number;
    itemId : number;
    itemname :string;
    quantity: number;
    category: string;
    // measurment: string;
}