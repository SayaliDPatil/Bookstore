import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-showitemlist',
  templateUrl: './customer-showitemlist.component.html',
  styleUrls: ['./customer-showitemlist.component.css']
})
export class CustomerShowitemlistComponent {

}
